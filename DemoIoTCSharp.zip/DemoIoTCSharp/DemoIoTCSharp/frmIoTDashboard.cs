﻿/******************************************************************************
 *  IoT Smart Device Development Board - IoT & C#.NET Winform                 *
 *  Dodit Suprianto | DSP-TECH | https://dsp-tech.gitbook.io                  *
 *  https://doditsuprianto.blogspot.com/ | https://github.com/doditsuprianto  *
 *  Email: doditsuprianto@gmail.com                                           *
 ******************************************************************************/
using System;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Windows.Media;
using LiveCharts;
using LiveCharts.Defaults;
using LiveCharts.Wpf;
using uPLibrary.Networking.M2Mqtt;
using uPLibrary.Networking.M2Mqtt.Messages;
using Newtonsoft.Json;
using System.Windows;

namespace DemoIoTCSharp
{
    public partial class frmIoTDashboard : Form
    {
        // class data json yang akan di deserialize
        public class DHT
        {
            public UInt32 suhu { get; set; }
            public UInt32 kelembaban { get; set; }
        }

        // Status relay dan buzzer, default OFF
        private String RelayState = "OFF";
        private String BuzzerState = "OFF";

        // Alamat IP dan Port Broker MQTT
        // Silahkan disesuaikan dengan alamat IP Broker MQTT Anda
        private const String IPBroker = "192.168.0.102";
        private const UInt16 PORT = 1883;

        // User & Password Broker MQTT 
        private const String userBroker = "AdminMQTT";
        private const String pwdBroker = "pwd123";

        // Topik Sensor
        private const String outTopicDHT = "/dht";
        private const String outTopicLDR = "/ldr";
        private const String outTopicSR04 = "/sr04";

        // Topik Aktuator
        private const String inTopicFAN = "/fanpwm";
        private const String inTopicRelay = "/relay";
        private const String inTopicLED = "/ledanim";
        private const String inTopicPiezo = "/piezo";

        static UInt32 nilaiLDR;
        static UInt32 nilaiSR04;
        static UInt32 nilaiSuhu;
        static UInt32 nilaiKelembaban;

        // Constructor koneksi client dengan Broker MQTT
        MqttClient client = new MqttClient(IPBroker, PORT, false, null, null, MqttSslProtocols.None);

        //public SeriesCollection SeriesCollection { get; set; }
        public ChartValues<ObservableValue> ValuesLDR { get; set; }
        public ChartValues<ObservableValue> ValuesSR04 { get; set; }

        public frmIoTDashboard()
        {
            InitializeComponent();

            // Text title Form
            this.Text = "IoT Dashboard System";

            // Text title tab page
            tabControl1.TabPages[0].Text = "Actuator";
            tabControl1.TabPages[1].Text = "Sensor LDR & Ultrasonic";
            tabControl1.TabPages[2].Text = "Sensor DHT11 (Suhu & Kelembaban)";

            // Text title checkbox
            cbRelay.Text = "Relay ON/OFF";
            cbBuzzer.Text = "Buzzer ON/OFF";

            // Mengubah warna background trackbar menjadi putih
            System.Drawing.SolidBrush putih = new System.Drawing.SolidBrush(System.Drawing.Color.White);
            SliderLED.BackColor = putih.Color;
            SliderFAN.BackColor = putih.Color;

            // Inisialisasi label text FAN dan LED
            lblValueFAN.Text = "0";
            lblValueLED.Text = "0";

            // Menjalin koneksi dengan Broker MQTT
            client.Connect(Guid.NewGuid().ToString(), userBroker, pwdBroker);

            // Membuat event dan memanggil method client_MqttMsgPublishReceived secara otomatis
            // ketika ada pesan MQTT yang masuk
            client.MqttMsgPublishReceived += client_MqttMsgPublishReceived;

            // Mendeklarasikan subscriber MQTT
            client.Subscribe(new string[] { outTopicLDR }, new byte[] { MqttMsgBase.QOS_LEVEL_EXACTLY_ONCE });
            client.Subscribe(new string[] { outTopicSR04 }, new byte[] { MqttMsgBase.QOS_LEVEL_EXACTLY_ONCE });
            client.Subscribe(new string[] { outTopicDHT }, new byte[] { MqttMsgBase.QOS_LEVEL_EXACTLY_ONCE });

            // Inisialisasi slider/trackbar LED
            SliderLED.Minimum = 0;
            SliderLED.Maximum = 9;
            SliderLED.Value = 0;

            // Inisialisasi slider/trackbar FAN
            SliderFAN.Minimum = 0;
            SliderFAN.Maximum = 100;
            SliderFAN.Value = 0;
            SliderFAN.TickFrequency = 10;

            // Constructor nilai chart
            ValuesLDR = new ChartValues<ObservableValue> { };
            ValuesSR04 = new ChartValues<ObservableValue> { };

            //chartIntensitasCahaya.LegendLocation = LegendLocation.Right;

            // Menentukan interval dan mengaktifkan timer LDR
            timerLDR.Interval = 300;
            timerLDR.Enabled = true;

            // Menentukan interval dan mengaktifkan timer Ultrasonic
            timerSR04.Interval = 500;
            timerSR04.Enabled = true;

            // Menentukan interval dan mengaktifkan timer DHT
            timerDHT.Interval = 1500;
            timerDHT.Enabled = true;
        }

        static void client_MqttMsgPublishReceived(object sender, MqttMsgPublishEventArgs e)
        {
            // Memeriksa topic dan menangkap data untuk diolah lebih lanjut
            if (e.Topic == outTopicDHT)
            {
                // Men-deserialisasi data json menjadi variable suhu dan kelembaban
                DHT dht = JsonConvert.DeserializeObject<DHT>(Encoding.UTF8.GetString(e.Message));
                nilaiSuhu = dht.suhu;
                nilaiKelembaban = dht.kelembaban;
            }
            else if (e.Topic == outTopicLDR)
            {
                // Menampung data LDR
                nilaiLDR = Convert.ToUInt32(Encoding.UTF8.GetString(e.Message));
            }
            else if (e.Topic == outTopicSR04)
            {
                //Menampung data jarak ultrasonic
                nilaiSR04 = Convert.ToUInt32(Encoding.UTF8.GetString(e.Message));
            }
        }

        private void cbRelay_CheckedChanged(object sender, EventArgs e)
        {
            // Mengecek status checkbox Relay
            if (cbRelay.Checked)
            {
                // Jika checkbox Relay dicentang maka status relay ON
                RelayState = "ON";
            }
            else
            {
                // Jika checkbox Relay tidak dicentang maka status relay OFF
                RelayState = "OFF";
            }

            // Memastikan pesan menjadi string sebelum di publish
            string strValue = Convert.ToString(RelayState);

            // publish pesan dengan topik inTopicRelay, QoS 2
            client.Publish(inTopicRelay, Encoding.UTF8.GetBytes(strValue), MqttMsgBase.QOS_LEVEL_EXACTLY_ONCE, false);
        }

        private void cbBuzzer_CheckedChanged(object sender, EventArgs e)
        {
            // Mengecek status checkbox Buzer
            if (cbBuzzer.Checked)
            {
                // Jika checkbox Buzzer dicentang maka status buzzer ON
                BuzzerState = "ON";
            }
            else
            {
                // Jika checkbox Buzzer dicentang maka status buzzer OFF
                BuzzerState = "OFF";
            }

            // Memastikan pesan menjadi string sebelum di publish
            string strValue = Convert.ToString(BuzzerState);

            // publish pesan dengan topik inTopicPiezo, QoS 2
            client.Publish(inTopicPiezo, Encoding.UTF8.GetBytes(strValue), MqttMsgBase.QOS_LEVEL_EXACTLY_ONCE, false);
        }

        private void frmIoTDashboard_Load(object sender, EventArgs e)
        {
            //*******************************
            // Timeseries Intensitas Cahaya
            // Sensor LDR
            //*******************************
            chartIntensitasCahaya.Series.Add(new LineSeries
            {
                Values = ValuesLDR,
                StrokeThickness = 2,
                PointGeometrySize = 10,
                DataLabels = true,
                //Stroke = Brushes.Yellow,
            });

            chartIntensitasCahaya.AxisX.Add(new LiveCharts.Wpf.Axis
            {
                Title = "Waktu",
            });


            chartIntensitasCahaya.AxisY.Add(new LiveCharts.Wpf.Axis
            {
                Title = "Intensitas Cahaya",
                LabelFormatter = x => x + " lux"
            });


            //******************************
            // Timeseries Jarak Penghalang
            // Sensor HC-SR04
            //******************************
            chartJarakPenghalang.Series.Add(new LineSeries
            {
                Values = ValuesSR04,
                StrokeThickness = 2,
                PointGeometrySize = 10,
                DataLabels = true,
                Stroke = Brushes.Red,
                Fill = Brushes.Transparent
            });

            chartJarakPenghalang.AxisX.Add(new LiveCharts.Wpf.Axis
            {
                Title = "Waktu",
            });


            chartJarakPenghalang.AxisY.Add(new LiveCharts.Wpf.Axis
            {
                Title = "Jarak Penghalang",
                LabelFormatter = x => x + " cm"
            });
        }

        private void frmIoTDashboard_FormClosed(object sender, FormClosedEventArgs e)
        {
            // Memutuskan koneksi dengan Broker MQTT ketika Form Closed
            client.Disconnect();

            // Memnonaktifkan timer ketika Form Closed
            timerDHT.Enabled = false;
            timerLDR.Enabled = false;
            timerSR04.Enabled = false;
        }

        private void timerLDR_Tick(object sender, EventArgs e)
        {
            // Maksimum 30 data ditampilkan dalam satu chart
            if (ValuesLDR.Count() > 30)
            {
                // Jika lebih dari 30 data maka data index ke-0 dihapus
                // berarti shift data ke kiri atau bergeser ke kiri
                ValuesLDR.RemoveAt(0);
            }
            else
            {
                // Jika kurang dari 30 data maka akan ditambah di sebelah kanan
                ValuesLDR.Add(new ObservableValue(nilaiLDR));
            }
        }

        private void timerSR04_Tick(object sender, EventArgs e)
        {
            // Maksimum 20 data ditampilkan dalam satu chart
            if (ValuesSR04.Count() > 20)
            {
                // Jika lebih dari 20 data maka data index ke-0 dihapus
                // berarti shift data ke kiri atau bergeser ke kiri
                ValuesSR04.RemoveAt(0);
            }
            else
            {
                // Jika kurang dari 20 data maka akan ditambah di sebelah kanan
                ValuesSR04.Add(new ObservableValue(nilaiSR04));
            }
        }

        private void timerDHT_Tick(object sender, EventArgs e)
        {
            // Gauge suhu
            solidGaugeSuhu.Uses360Mode = true;
            solidGaugeSuhu.From = 0;
            solidGaugeSuhu.To = 100;
            solidGaugeSuhu.Value = nilaiSuhu;

            // Gauge kelembaban
            solidGaugeKelembaban.From = 0;
            solidGaugeKelembaban.To = 100;
            solidGaugeKelembaban.Value = nilaiKelembaban;
            solidGaugeKelembaban.Base.LabelsVisibility = Visibility.Hidden;
            solidGaugeKelembaban.Base.GaugeActiveFill = new LinearGradientBrush
            {
                GradientStops = new GradientStopCollection
                {
                    new GradientStop(Colors.Yellow, 0),
                    new GradientStop(Colors.Orange, .5),
                    new GradientStop(Colors.Red, 1)
                }
            };
        }

        private void sliderLED_Scroll(object sender, EventArgs e)
        {
            // Mengkonversi value slider menjadi string
            String strValue = SliderLED.Value.ToString();

            //Menampilkan value slider pada label lblValueLED
            lblValueLED.Text = strValue;

            // Mengirim pesan ke Broker MQTT
            client.Publish(inTopicLED, Encoding.UTF8.GetBytes(strValue), MqttMsgBase.QOS_LEVEL_EXACTLY_ONCE, false);
        }

        private void sliderFAN_Scroll(object sender, EventArgs e)
        {
            int value = (sender as TrackBar).Value;
            double indexDbl = (value * 1.0) / SliderFAN.TickFrequency;
            int index = Convert.ToInt32(Math.Round(indexDbl));
            SliderFAN.Value = SliderFAN.TickFrequency * index;

            // Mengkonversi value slider menjadi string
            String strValue = SliderFAN.Value.ToString();

            //Menampilkan value slider pada label lblValueFAN
            lblValueFAN.Text = strValue;

            // Mengirim pesan ke Broker MQTT
            client.Publish(inTopicFAN, Encoding.UTF8.GetBytes(strValue), MqttMsgBase.QOS_LEVEL_EXACTLY_ONCE, false);
        }
    }
}
