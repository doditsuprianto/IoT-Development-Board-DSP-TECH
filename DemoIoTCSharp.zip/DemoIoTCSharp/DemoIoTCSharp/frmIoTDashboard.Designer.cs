﻿namespace DemoIoTCSharp
{
    partial class frmIoTDashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.lblValueFAN = new System.Windows.Forms.Label();
            this.lblValueLED = new System.Windows.Forms.Label();
            this.SliderFAN = new System.Windows.Forms.TrackBar();
            this.SliderLED = new System.Windows.Forms.TrackBar();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.cbBuzzer = new System.Windows.Forms.CheckBox();
            this.cbRelay = new System.Windows.Forms.CheckBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.chartJarakPenghalang = new LiveCharts.WinForms.CartesianChart();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.chartIntensitasCahaya = new LiveCharts.WinForms.CartesianChart();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.solidGaugeKelembaban = new LiveCharts.WinForms.SolidGauge();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.solidGaugeSuhu = new LiveCharts.WinForms.SolidGauge();
            this.timerLDR = new System.Windows.Forms.Timer(this.components);
            this.timerDHT = new System.Windows.Forms.Timer(this.components);
            this.timerSR04 = new System.Windows.Forms.Timer(this.components);
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.SliderFAN)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SliderLED)).BeginInit();
            this.tabPage2.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(800, 495);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.lblValueFAN);
            this.tabPage1.Controls.Add(this.lblValueLED);
            this.tabPage1.Controls.Add(this.SliderFAN);
            this.tabPage1.Controls.Add(this.SliderLED);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Controls.Add(this.cbBuzzer);
            this.tabPage1.Controls.Add(this.cbRelay);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(792, 469);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Actuator";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // lblValueFAN
            // 
            this.lblValueFAN.AutoSize = true;
            this.lblValueFAN.Location = new System.Drawing.Point(58, 198);
            this.lblValueFAN.Name = "lblValueFAN";
            this.lblValueFAN.Size = new System.Drawing.Size(13, 13);
            this.lblValueFAN.TabIndex = 7;
            this.lblValueFAN.Text = "0";
            // 
            // lblValueLED
            // 
            this.lblValueLED.AutoSize = true;
            this.lblValueLED.Location = new System.Drawing.Point(59, 143);
            this.lblValueLED.Name = "lblValueLED";
            this.lblValueLED.Size = new System.Drawing.Size(13, 13);
            this.lblValueLED.TabIndex = 6;
            this.lblValueLED.Text = "0";
            // 
            // SliderFAN
            // 
            this.SliderFAN.Location = new System.Drawing.Point(138, 167);
            this.SliderFAN.Name = "SliderFAN";
            this.SliderFAN.Size = new System.Drawing.Size(602, 45);
            this.SliderFAN.TabIndex = 5;
            this.SliderFAN.Scroll += new System.EventHandler(this.sliderFAN_Scroll);
            // 
            // SliderLED
            // 
            this.SliderLED.Location = new System.Drawing.Point(138, 112);
            this.SliderLED.Name = "SliderLED";
            this.SliderLED.Size = new System.Drawing.Size(602, 45);
            this.SliderLED.TabIndex = 4;
            this.SliderLED.Scroll += new System.EventHandler(this.sliderLED_Scroll);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(33, 167);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(62, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Speed FAN";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(33, 112);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(75, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "LED Controller";
            // 
            // cbBuzzer
            // 
            this.cbBuzzer.AutoSize = true;
            this.cbBuzzer.Location = new System.Drawing.Point(36, 68);
            this.cbBuzzer.Name = "cbBuzzer";
            this.cbBuzzer.Size = new System.Drawing.Size(102, 17);
            this.cbBuzzer.TabIndex = 1;
            this.cbBuzzer.Text = "Buzzer ON/OFF";
            this.cbBuzzer.UseVisualStyleBackColor = true;
            this.cbBuzzer.CheckedChanged += new System.EventHandler(this.cbBuzzer_CheckedChanged);
            // 
            // cbRelay
            // 
            this.cbRelay.AutoSize = true;
            this.cbRelay.Location = new System.Drawing.Point(36, 28);
            this.cbRelay.Name = "cbRelay";
            this.cbRelay.Size = new System.Drawing.Size(97, 17);
            this.cbRelay.TabIndex = 0;
            this.cbRelay.Text = "Relay ON/OFF";
            this.cbRelay.UseVisualStyleBackColor = true;
            this.cbRelay.CheckedChanged += new System.EventHandler(this.cbRelay_CheckedChanged);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.groupBox2);
            this.tabPage2.Controls.Add(this.groupBox1);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(792, 469);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Sensor LDR & Ultrasonic";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.chartJarakPenghalang);
            this.groupBox2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox2.Location = new System.Drawing.Point(3, 242);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(786, 224);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Jarak Penghalang [Sensor Ultrasonic]";
            // 
            // chartJarakPenghalang
            // 
            this.chartJarakPenghalang.Dock = System.Windows.Forms.DockStyle.Fill;
            this.chartJarakPenghalang.Location = new System.Drawing.Point(3, 16);
            this.chartJarakPenghalang.Name = "chartJarakPenghalang";
            this.chartJarakPenghalang.Size = new System.Drawing.Size(780, 205);
            this.chartJarakPenghalang.TabIndex = 0;
            this.chartJarakPenghalang.Text = "cartesianChart1";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.chartIntensitasCahaya);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox1.Location = new System.Drawing.Point(3, 3);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(786, 239);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Intensitas Cahaya [Sensor LDR]";
            // 
            // chartIntensitasCahaya
            // 
            this.chartIntensitasCahaya.Dock = System.Windows.Forms.DockStyle.Fill;
            this.chartIntensitasCahaya.Location = new System.Drawing.Point(3, 16);
            this.chartIntensitasCahaya.Name = "chartIntensitasCahaya";
            this.chartIntensitasCahaya.Size = new System.Drawing.Size(780, 220);
            this.chartIntensitasCahaya.TabIndex = 0;
            this.chartIntensitasCahaya.Text = "cartesianChart1";
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.groupBox4);
            this.tabPage3.Controls.Add(this.groupBox3);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(792, 469);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Sensor DHT11 (Suhu & Kelembaban)";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.solidGaugeKelembaban);
            this.groupBox4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox4.Location = new System.Drawing.Point(406, 3);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(383, 463);
            this.groupBox4.TabIndex = 1;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Kelembaban";
            // 
            // solidGaugeKelembaban
            // 
            this.solidGaugeKelembaban.Dock = System.Windows.Forms.DockStyle.Fill;
            this.solidGaugeKelembaban.Location = new System.Drawing.Point(3, 16);
            this.solidGaugeKelembaban.Name = "solidGaugeKelembaban";
            this.solidGaugeKelembaban.Size = new System.Drawing.Size(377, 444);
            this.solidGaugeKelembaban.TabIndex = 0;
            this.solidGaugeKelembaban.Text = "solidGauge1";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.solidGaugeSuhu);
            this.groupBox3.Dock = System.Windows.Forms.DockStyle.Left;
            this.groupBox3.Location = new System.Drawing.Point(3, 3);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(403, 463);
            this.groupBox3.TabIndex = 0;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Suhu";
            // 
            // solidGaugeSuhu
            // 
            this.solidGaugeSuhu.Dock = System.Windows.Forms.DockStyle.Fill;
            this.solidGaugeSuhu.Location = new System.Drawing.Point(3, 16);
            this.solidGaugeSuhu.Name = "solidGaugeSuhu";
            this.solidGaugeSuhu.Size = new System.Drawing.Size(397, 444);
            this.solidGaugeSuhu.TabIndex = 0;
            this.solidGaugeSuhu.Text = "solidGauge1";
            // 
            // timerLDR
            // 
            this.timerLDR.Tick += new System.EventHandler(this.timerLDR_Tick);
            // 
            // timerDHT
            // 
            this.timerDHT.Tick += new System.EventHandler(this.timerDHT_Tick);
            // 
            // timerSR04
            // 
            this.timerSR04.Tick += new System.EventHandler(this.timerSR04_Tick);
            // 
            // frmIoTDashboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 495);
            this.Controls.Add(this.tabControl1);
            this.Name = "frmIoTDashboard";
            this.Text = "IoT Dashbord System";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.frmIoTDashboard_FormClosed);
            this.Load += new System.EventHandler(this.frmIoTDashboard_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.SliderFAN)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SliderLED)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.Label lblValueFAN;
        private System.Windows.Forms.Label lblValueLED;
        private System.Windows.Forms.TrackBar SliderFAN;
        private System.Windows.Forms.TrackBar SliderLED;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.CheckBox cbBuzzer;
        private System.Windows.Forms.CheckBox cbRelay;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox1;
        private LiveCharts.WinForms.CartesianChart chartJarakPenghalang;
        private LiveCharts.WinForms.CartesianChart chartIntensitasCahaya;
        private System.Windows.Forms.GroupBox groupBox4;
        private LiveCharts.WinForms.SolidGauge solidGaugeKelembaban;
        private System.Windows.Forms.GroupBox groupBox3;
        private LiveCharts.WinForms.SolidGauge solidGaugeSuhu;
        private System.Windows.Forms.Timer timerLDR;
        private System.Windows.Forms.Timer timerDHT;
        private System.Windows.Forms.Timer timerSR04;
    }
}

